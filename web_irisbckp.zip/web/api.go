package main

import (
	"github.com/kataras/iris"
)

func main() {

	app := iris.New()

	app.Get("/json", func(ctx iris.Context) {
		ctx.JSON(iris.Map{"result": "Hello World!"})
	})

	app.Listen(":8081")
}
